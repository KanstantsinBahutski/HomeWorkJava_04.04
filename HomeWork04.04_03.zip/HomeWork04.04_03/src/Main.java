import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите имя текущего месяца: ");
        String currentMonthName = scanner.nextLine().toUpperCase();

        Month currentMonth = Month.valueOf(currentMonthName);

        System.out.print("Остальные месяцы: ");
        for (Month month : Month.values()) {
            if (month != currentMonth) {
                System.out.print(month.name() + " ");
            }
        }
    }
}