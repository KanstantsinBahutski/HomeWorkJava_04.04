import java.util.Random;

public class Main {
    public static void main(String[] args) {
        int total = 0;
        int neededAmount = 100000;
        Random random = new Random();

        while (total < neededAmount) {
            System.out.println("Текущая сумма сборов: " + total);
            int friendGift = 0;
            int randomInt = random.nextInt(4);
            switch (randomInt) {
                case 0:
                    friendGift = 500;
                    break;
                case 1:
                    friendGift = 1000;
                    break;
                case 2:
                    friendGift = 2000;
                    break;
                case 3:
                    friendGift = 5000;
                    break;
            }
            total += friendGift;
        }

        System.out.println("Ура! Друзья собрали нужную сумму в " + total + " рублей!");
        System.out.println("Всех приглашаю в лучший бар города!");
    }
}
