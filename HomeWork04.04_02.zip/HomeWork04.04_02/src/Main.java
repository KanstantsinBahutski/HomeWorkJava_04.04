import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите нижнюю границу диапазона: ");
        int lowerBound = scanner.nextInt();

        System.out.print("Введите верхнюю границу диапазона: ");
        int upperBound = scanner.nextInt();

        int sum = 0;
        for (int i = lowerBound; i <= upperBound; i++) {
            if (i % 2 == 1) {
                sum += i;
            }
        }

        System.out.println("Сумма нечетных чисел в диапазоне от " + lowerBound + " до " + upperBound + " равна " + sum);
    }
}
